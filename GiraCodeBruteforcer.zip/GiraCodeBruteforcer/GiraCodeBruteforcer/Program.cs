﻿using System;
using System.Drawing;
using System.Runtime.InteropServices;

class Program
{
    static void Main()
    {
        [DllImport("user32.dll")]
        static extern bool SetCursorPos(int X, int Y);
        [DllImport("user32.dll")]
        static extern void mouse_event(int dwFlags, int dx, int dy, int cButtons, int dwExtraInfo);
        [DllImport("user32.dll")]        
        static extern IntPtr GetDC(IntPtr hwnd);
        [DllImport("gdi32.dll")]        
        static extern uint GetPixel(IntPtr hdc, int x, int y);

        const int MOUSEEVENTF_LEFTDOWN = 0x02;
        const int MOUSEEVENTF_LEFTUP = 0x04;

        //Position values are for 1920x1080 resolution and 100% scale in Windows
        int[] x = { 760, 660, 760, 860, 660, 760, 860, 660, 760, 860 };
        int[] y = { 750, 420, 420, 420, 530, 530, 530, 640, 640, 640 };

        Thread.Sleep(10000);
        Console.Write("Running GiraCodeBruteforcer...\n\n");

        for (int i = 0;i < 10000; i++)
        {
            string code = i.ToString("D4");
            for (int j = 0; j < code.Length; j++)
            {
                int a = x[(int)Char.GetNumericValue(code[j])];
                int b = y[(int)Char.GetNumericValue(code[j])];
                SetCursorPos(a, b);
                mouse_event(MOUSEEVENTF_LEFTDOWN | MOUSEEVENTF_LEFTUP, a, b, 0, 0);           
                Console.Write("X: " + a + " Y: " + b + " ");
                Thread.Sleep(10);
            }
            Console.Write("\nCode: " + code);
            Thread.Sleep(25);
            uint color = GetPixel(GetDC(IntPtr.Zero), 1200, 600);
            int red = (int)(color & 0x000000FF);
            int green = (int)((color & 0x0000FF00) >> 8);
            int blue = (int)((color & 0x00FF0000) >> 16);
            Console.Write(" (R: " + red + ", G: " + green + ", B: " + blue + ")\n\n");
            if (red != 133 && green != 201 && blue != 133) //HomeServer 3: R:133, G:201, B:133 | HomeServer 4: R:45, G:45, B:45
            {
                Console.Write("\nDone!\n");
                Environment.Exit(0);
            }
        }
    }
}